#!/bin/bash
# 修改为上一个镜像版本
PRE_REVISION=$(awk '/Previous/{revision=$1}END{print revision}' revision.svn)
sed -i -r '/:5000/s/[0-9]+$/'$PRE_REVISION'/' docker-compose.yml

# 当前有问题的版本记录
sed -i '$d' revision.svn

sudo docker-compose down
sudo docker-compose up -d
