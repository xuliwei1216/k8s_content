#!/bin/bash
scp -r root@10.10.6.105:/home/app/lnmp/wwwroot/* /home/app/lnmp/wwwroot/
REVISION=revision.svn
IMAGE_REPOS=http://10.10.6.107:5000/v2
# 获取最新镜像tag
LATEST_REVISION=$(curl $IMAGE_REPOS/lnmp-nginx/tags/list |\
grep -Po '(?<=")\d+(?=")' |\
awk 'BEGIN{max=0}{for(i=1;i<=NF;i++)if($i>max)max=$i}END{print max}') 

sed -i -r '/:5000/s/[0-9]+$/'$LATEST_REVISION'/' docker-compose.yml

# 标记上一个版本和当前版本
if ! grep "^$LATEST_REVISION " $REVISION &>/dev/null; then
   sed -i -r '$s/([0-9]+).*/\1 Previous/' $REVISION
   echo "$LATEST_REVISION Current" >> $REVISION
fi

sudo docker-compose down
sudo docker-compose up -d
