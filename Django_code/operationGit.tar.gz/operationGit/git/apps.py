from django.apps import AppConfig


class GitConfig(AppConfig):
    name = 'git'
