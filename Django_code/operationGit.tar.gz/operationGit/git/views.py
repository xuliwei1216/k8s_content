from django.shortcuts import render
from django.core.paginator import Paginator
import datetime
import time
import re
import os
from django.views.decorators.csrf import csrf_exempt

# Create your views here.

a = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
b = time.strftime("%Y-%m-%d", time.localtime())

def index(request):
    return render(request, 'index.html')

@csrf_exempt
def testpost(request):
    user = request.POST['user']

    date = request.POST['date']

    project = request.POST['project']

    #count = request.POST.getlist('count')

    count = request.POST['count']

    context = {'user':user, 'date':date, 'project':project, 'count':count}
    print(context)
    exec_for(user,date,project,count,a)
    return render(request,'testpost.html',context)

def exec_for(user,date,project,count,a):
    info = {"user":user,"date":date,"project":project,"count":count,"datenow":a}
    f = open("/home/app/django/logs/operation.txt", 'a+', encoding='utf8')             # 返回一个文件对象
    print(info)
    line = f.writelines('%s\n'%(info))             # 调用文件的 writeline()方法
    print(line)
    f.close()

    f = open("/home/app/django/auto_product_solo/auto_operation.log", 'a+', encoding='utf8')
    line = f.writelines('%s\n'%(info))
    f.close()

    os.system('sh /home/app/django/scripts/gitpull.sh')
